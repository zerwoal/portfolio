---
name: Enhancement
about: Suggest an improvement
title: ''
labels: C-enhancement
assignees: ''
---

<!--
Your enhancement may already be reported!
Please search on the issue tracker before creating a new issue.
If this is an idea for a feature, please open an "Idea" Discussion instead.
-->
