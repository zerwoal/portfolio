# helix-tui

This library is a fork of the great library
[tui-rs](https://github.com/fdehau/tui-rs/). We've mainly relied on the double
buffer implementation and render diffing, side-stepping its widget and
layouting.
